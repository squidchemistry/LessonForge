# QC Layer 1 - Research & Factual Accuracy

**Verdict:** pass  |  **Score:** 95/100  |  **Run:** 2026-11-07T07:51:40.736Z

This lesson provides an exceptionally clear, accurate, and pedagogically sound introduction to Big-O notation and time complexity. The code snippets, scaling explanations, and historical references are fully supported by standard computer science literature and independent search evidence. Minor source rating adjustments are noted due to missing transcripts or general overviews, but the instructional content itself is exemplary.

## Claim verification

| Section | Claim | Status | Evidence |
|---|---|---|---|
| sec-1 | Big-O notation provides a machine-independent way to describe performance and how code slows down as data grows. | **supported** | Supported by source [S11] and [S13] which state that Big-O describes runtime scaling relative to input size independently of hardware. S11 S13 |
| sec-2 | Big-O notation is named after German number theoretician Edmund Landau, also called Landau's symbol. | **supported** | Confirmed by historical definitions of Landau's symbol in complexity theory. S2 |
| sec-2 | When evaluating algorithms, we focus on the worst-case scenario, determining an upper bound on the time required. | **supported** | Supported by sources [S4], [S6], and [S7] which confirm Big-O represents an asymptotic upper bound in the worst-case scenario. S4 S6 S7 |
| sec-2 | A foundational rule of Big-O analysis is that we drop constants and lower-order terms. | **supported** | Confirmed by source [S2] and standard algebraic rules for asymptotic growth where lower-order terms and constants become insignificant for large n. S2 S11 S13 |
| sec-2 | Constant Time, or O(1), executes a fixed number of operations regardless of how large the input dataset becomes. | **supported** | Supported by sources [S3], [S4], [S7], and independent literature on constant time complexity. S3 S4 S7 |
| sec-3 | Linear Time (O(n)) occurs when execution time scales directly and proportionally with the size of the input. | **supported** | Supported by sources [S4], [S6], [S7], and [S11]. S4 S6 S7 S11 |
| sec-3 | Logarithmic Time (O(log n)) describes algorithms where the problem size is reduced by half with each step, such as in binary search. | **supported** | Supported by source [S7] and general computer science definitions of logarithmic runtime. S7 |
| sec-3 | Quadratic Time (O(n^2)) typically occurs when dealing with nested loops running inside another loop. | **supported** | Supported by source [S7] and independent evidence regarding nested loops. S7 |
| sec-4 | Iterative summation add_up_iterative(n) runs in O(n) linear time. | **supported** | Supported by source [S11] which uses the exact same function example to demonstrate O(n) loops. S11 |
| sec-4 | Using Gauss's summation formula n * (n + 1) // 2 executes in O(1) constant time. | **supported** | Supported by source [S5] and [S11] demonstrating constant arithmetic operations regardless of n. S5 S11 |
| sec-5 | Snippet A checking arr[0] and arr[-1] is O(1) because it accesses fixed indices directly without loops. | **supported** | Supported by source [S4] and [S7] regarding direct array index access. S4 S7 |
| sec-5 | Snippet B searching an item via a single loop is O(n) in the worst case. | **supported** | Supported by source [S7] and [S8] on linear search complexity. S7 S8 |
| sec-5 | Snippet C duplicating a matrix with nested loops is O(n^2). | **supported** | Supported by source [S7] on nested loop quadratic complexity. S7 |
| quiz | Q1 answer correctly identifies Big-O as describing asymptotic growth of an algorithm's resource usage as input size increases. | **supported** | Backed by sources [S2], [S11], [S13]. S2 S11 S13 |
| quiz | Q4 answer correctly identifies nested loops scaling with input size n as O(n^2). | **supported** | Backed by source [S7]. S7 |

## Source assessment

| Source | Reliability | Relevance | Note |
|---|---|---|---|
| S1 | high | medium | Wikipedia article on time complexity, relevant background. |
| S2 | high | high | MIT lecture notes on Big O notation and formal definitions. |
| S3 | medium | high | Educational tutorial explaining complexity classes with examples. |
| S4 | medium | high | Medium article on time and space complexity. |
| S5 | medium | medium | DEV community post showing common complexities and formulas. |
| S6 | high | high | GeeksforGeeks tutorial on analysis of algorithms and upper bounds. |
| S7 | high | high | freeCodeCamp Big-O cheat sheet and chart explanation. |
| S8 | high | medium | Big-O algorithm complexity cheat sheet reference table. |
| S9 | medium | low | GeeksforGeeks video without direct transcript in pack. |
| S10 | medium | low | Codebasics video without direct transcript in pack. |
| S11 | medium | high | Bro Code video tutorial with transcript excerpt on Big-O basics. |
| S12 | medium | medium | Gate Smashers video on asymptotic notations. |
| S13 | high | high | NeetCode video tutorial transcript on interview time complexities. |

## Link checks

- OK (200) https://en.wikipedia.org/wiki/Time_complexity
- OK (200) https://web.mit.edu/16.070/www/lecture/big_o.pdf
- OK (200) https://happycoders.eu/algorithms/big-o-notation-time-complexity
- BLOCKED (403) https://medium.com/@DevChy/introduction-to-big-o-notation-time-and-space-complexity-f747ea5bca58
- OK (200) https://dev.to/davinceleecode/time-complexity-big-o-notation-in-algorithms-22lf
- OK (200) https://www.geeksforgeeks.org/dsa/analysis-algorithms-big-o-analysis
- OK (200) https://www.freecodecamp.org/news/big-o-cheat-sheet-time-complexity-chart
- OK (200) https://www.bigocheatsheet.com
- OK (200) https://www.youtube.com/watch?v=XMUe3zFhM5c
- OK (200) https://www.youtube.com/watch?v=7dz8Iaf_weM
- OK (200) https://www.youtube.com/watch?v=BgLTDT03QtU

## Independent verification searches

- "Big-O notation definition asymptotic growth upper bound" -> https://www2.cs.arizona.edu/classes/cs345/summer14/files/bigO.pdf, https://jasonroell.com/blog/know-your-big-o, https://www.khanacademy.org/computing/computer-science/algorithms/asymptotic-notation/a/big-o-notation
- "dropping constants and lower-order terms in Big-O analysis rule" -> https://medium.com/@pixelreverb/algorithm-fundamentals-the-big-o-notation-41fe896a23ff, https://pages.cs.wisc.edu/~vernon/cs367/notes/3.COMPLEXITY.html, https://www.youtube.com/watch?v=QSPFvHqI99g
- "O(1) constant time complexity definition algorithm" -> https://www.sciencedirect.com/topics/computer-science/constant-time-complexity, https://dev.to/tkarropoulos/understanding-time-complexity-o-notation-in-software-engineering-1ad1, https://www.geeksforgeeks.org/dsa/what-does-constant-time-complexity-or-big-o1-mean
- "nested loops quadratic time complexity O(n^2)" -> https://www.geeksforgeeks.org/dsa/what-does-big-on2-complexity-mean, https://stackoverflow.com/questions/526728/time-complexity-of-nested-for-loop, https://medium.com/@samyuktha1262/think-nested-loops-are-always-o-n%C2%B2-think-again-7f1a41640e74

## Gaps

- Space complexity is mentioned only briefly in source materials but omitted as a core focus in this lesson, which is acceptable given the 45-minute timebox and time-complexity objective, but worth noting.

## Issues and suggested improvements

_No issues found._