# References - Big-O Notation and Algorithm Complexity

1. [Time complexity - Wikipedia](https://en.wikipedia.org/wiki/Time_complexity) - _web_, en.wikipedia.org
2. [Big O notation (with a capital letter O, not a zero), also ...](https://web.mit.edu/16.070/www/lecture/big_o.pdf) - _web_, web.mit.edu
3. [Big O Notation and Time Complexity – Easily Explained](https://happycoders.eu/algorithms/big-o-notation-time-complexity) - _web_, happycoders.eu
4. [Mastering Big O Notation: Understanding Time and Space Complexity in Algorithms](https://medium.com/@DevChy/introduction-to-big-o-notation-time-and-space-complexity-f747ea5bca58) - _web_, medium.com
5. [Time Complexity (Big-O Notation) in Algorithms - DEV Community](https://dev.to/davinceleecode/time-complexity-big-o-notation-in-algorithms-22lf) - _web_, dev.to
6. [Big O Notation - GeeksforGeeks](https://www.geeksforgeeks.org/dsa/analysis-algorithms-big-o-analysis) - _web_, geeksforgeeks.org
7. [Big O Cheat Sheet – Time Complexity Chart](https://www.freecodecamp.org/news/big-o-cheat-sheet-time-complexity-chart) - _web_, freecodecamp.org
8. [Big-O Algorithm Complexity Cheat Sheet (Know Thy Complexities!) @ericdrowell](https://www.bigocheatsheet.com) - _web_, bigocheatsheet.com
11. [Learn Big O notation in 6 minutes 📈](https://www.youtube.com/watch?v=XMUe3zFhM5c) - _video_, youtube.com
12. [L-1.3: Asymptotic Notations | Big O | Big Omega | Theta Notations | Most Imp Topic Of Algorithm](https://www.youtube.com/watch?v=7dz8Iaf_weM) - _video_, youtube.com
13. [Big-O Notation - For Coding Interviews](https://www.youtube.com/watch?v=BgLTDT03QtU) - _video_, youtube.com

## Researched but not cited

- [Time and Space Complexity explained in literally 5 minutes | Big O | Concepts made simple ep -1](https://www.youtube.com/watch?v=jOMxKsUd6e0) (video)
- [Big O notation - Data Structures & Algorithms Tutorial #2 | Measuring time complexity](https://www.youtube.com/watch?v=IR_S8BC8KI0) (video)

## Acknowledgement

Content was synthesised (paraphrased, not copied) with an AI model from the sources above. Sources are credited to their original authors.
