# QC Layer 2 - Instructional Quality

**Verdict:** needs_revision  |  **Score:** 82/100  |  **Run:** 2026-11-07T07:51:59.657Z

This lesson provides an engaging, well-structured introduction to Big-O notation with strong conceptual framing and practical code examples. However, it exhibits a critical instructional gap regarding $O(\log n)$ behavior: while the concept is mentioned briefly in text and tested in the quiz, no code example or hands-on practice snippet is provided for $O(\log n)$ code identification, leaving that part of the objective only partially taught and assessed. Additionally, the hands-on activity section lacks explicit instructions for learners to execute their trace.

## Alignment with learning objective (4/5)

| Objective part | Coverage | Taught in | Assessed by | Note |
|---|---|---|---|---|
| Compare the time complexity of common algorithms using Big-O notation | **full** | sec-2, sec-3, sec-4 | Q3 | Covered comprehensively through comparison tables, narratives, and the Gauss formula example. |
| identify O(1), O(n), O(log n) and O(n^2) behaviour in simple code | **partial** | sec-2, sec-3, sec-5 | Q4, Q5 | O(1), O(n), and O(n^2) are well-taught and practiced in snippets A, B, and C. However, O(log n) code is completely missing from the code examples and hands-on activity, making its identification in code unpracticed prior to the quiz. |

## Dimension scores

| Dimension | Score | Note |
|---|---|---|
| Clarity | 5/5 | Definitions are sharp, terminology is introduced naturally, and foundational rules like dropping constants are clearly articulated. |
| Structure & flow | 5/5 | Logical progression from hook to core concepts, end-to-end analysis, hands-on practice, quiz, and wrap-up. |
| Relevance | 5/5 | All content directly supports time complexity analysis without fluff or off-topic diversions. |
| Examples | 4/5 | Strong code examples for O(1), O(n), and O(n^2). Lacks a code example for O(log n) (e.g., binary search or a simple loop dividing a counter). |
| Practical application | 4/5 | The hands-on activity gives learners code snippets to classify, which builds real coding intuition, but omitting O(log n) code limits complete mastery. |
| Assessment quality | 4/5 | Quiz questions are well-written and target conceptual understanding effectively. Q5 tests O(log n) via a scenario, though matching quiz items to a practiced code snippet for O(log n) would improve constructive alignment. |
| Engagement | 5/5 | Uses compelling hooks (scaling from 100 to 10M records) and relatable comparisons (iterative vs. mathematical formula). |
| Timing realism | 5/5 | Reading volume (~1,000 words) and activity budgets fit comfortably within the 45-minute lesson window. |

## Gaps

- Missing code example and hands-on practice snippet for O(log n) behavior.
- Hands-on activity does not explicitly prompt learners to write down or verify their answers before reading the expected results.

## Issues and suggested improvements

### 🟠 I1 - MAJOR (alignment) in `sec-3`  _[open]_

**Problem:** The lesson objective requires learners to 'identify O(1), O(n), O(log n) and O(n^2) behaviour in simple code', but O(log n) code is never shown or practiced in any code example or hands-on snippet.

**Evidence:** Sec-3 defines O(log n) textually ('algorithm where the problem size is reduced by half with each step'), but provides no corresponding code snippet (such as a simple binary search or while loop dividing n by 2).

**Suggestion:** Add an O(log n) code snippet (e.g., a loop dividing n by 2) to Core Concept 2 or the Hands-On Activity so learners can identify it in code.

**Proposed change (replace):**

> Before: ### Code Comparison of $O(n)$ vs $O(n^2)$ ```python # O(n) Linear Time: Single loop over input def print_items(arr):     for item in arr:         print(item)  # O(n^2) Quadratic Time: Nested loops over input def print_pairs(arr):     for i in arr:         for j in arr:             print(i, j) ```
> After: ### Code Comparison of $O(n)$, $O(\log n)$, and $O(n^2)$ ```python # O(n) Linear Time: Single loop over input def print_items(arr):     for item in arr:         print(item)  # O(log n) Logarithmic Time: Input size halved each step def find_power_of_two(n):     count = 0     while n > 1:         n = n // 2         count += 1     return count  # O(n^2) Quadratic Time: Nested loops over input def print_pairs(arr):     for i in arr:         for j in arr:             print(i, j) ```
