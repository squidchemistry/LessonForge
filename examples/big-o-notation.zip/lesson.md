# Big-O Notation and Algorithm Complexity

**Learning objective:** Compare the time complexity of common algorithms using Big-O notation and identify O(1), O(n), O(log n) and O(n^2) behaviour in simple code.

**Duration:** 45 minutes

This 45-minute lesson introduces Big-O notation as a machine-independent way to measure algorithm time complexity. Learners explore O(1), O(n), O(log n), and O(n^2) behaviors using conceptual breakdowns, code analysis, and interactive practice.

## By the end of this lesson you will be able to

- Define Big-O notation and explain its role in evaluating algorithm performance as input size grows.
- Compare the time complexity of common growth rates including O(1), O(n), O(log n), and O(n^2).
- Identify O(1), O(n), and O(n^2) behavior in simple code snippets containing loops or direct access.
- Evaluate worst-case asymptotic upper bounds by dropping constants and lower-order terms.

## The Algorithm Scaling Problem _(3 min)_

Imagine you write a script to search for a user profile in a database of 100 records, and it runs instantaneously. But what happens when your app goes viral, and your user base expands to 10 million records? Suddenly, your once-fast application grinds to a halt. Why does this happen? Different algorithms handle scaling in radically different ways. Some solutions require twice as much time when data doubles, while others take millions of times longer. To write software that scales successfully, we need a machine-independent way to describe performance [11][13]. We cannot rely on a stopwatch because a fast computer might make a bad algorithm look acceptable, while a slow machine might punish an efficient one [11]. Instead, computer scientists use Big-O notation to understand how code slows down as data grows [11][13].

## Core Concept 1: What is Big-O Notation and Constant Time O(1) _(10 min)_

Big-O notation (named after German number theoretician Edmund Landau, also called Landau's symbol) is a mathematical way to describe the asymptotic behavior of functions [2]. Specifically, it tells us how fast a function's resource usage grows or declines as the input size $n$ increases [2][11][13]. When evaluating algorithms, we focus on the worst-case scenario, determining an upper bound on the time required to complete a task [4][6][7]. 

A foundational rule of Big-O analysis is that we drop constants and lower-order terms [2][11][13]. For instance, if an algorithm takes $4n^2 - 2n + 2$ steps, constants like $4$ and $-2$, as well as lower-order terms like $2n$, are ignored because they become insignificant when $n$ grows extremely large [2]. Big-O focuses entirely on the dominant growth factor [2][11][13].

At the optimal end of the spectrum is **Constant Time, or $O(1)$** [3][7]. An algorithm with $O(1)$ time complexity executes a fixed number of operations regardless of how large the input array or dataset becomes [4]. Whether you pass an array of 5 elements or 5 million elements, the running time remains completely flat and unchanged [13]. 

### Example of $O(1)$ Code
```python
def get_first_element(arr):
    # Accessing an array element by index always takes a fixed number of steps
    return arr[0]
```

### Complexity Comparison Table
| Big-O Notation | Name | Scaling Behavior | Relative Performance |
| --- | --- | --- | --- |
| $O(1)$ | Constant Time | Unaffected by input size | Excellent [7] |
| $O(\log n)$ | Logarithmic Time | Grows slowly as input multiplies | Good [7] |
| $O(n)$ | Linear Time | Scales directly with input size | Fair [7] |
| $O(n^2)$ | Quadratic Time | Proportional to the square of input | Horrible / Worst [7] |

## Core Concept 2: Linear O(n), Logarithmic O(log n), and Quadratic O(n^2) Time _(10 min)_

Moving past constant time, we encounter several other standard complexity classes that dictate how algorithms perform under load [3][7]. 

**Linear Time ($O(n)$)** occurs when an algorithm's execution time scales directly and proportionally with the size of the input [4][6][7]. If you have a single loop that iterates across an entire collection of items from 0 to $n$, doubling the input size doubles the number of operations [7][11]. For example, searching an unsorted array item-by-item requires checking each element in the worst case, yielding linear time [8].

**Logarithmic Time ($O(\log n)$)** describes algorithms where the problem size is reduced by half with each step, such as in binary search [7]. As the input grows exponentially, the number of operations increases only linearly. This makes $O(\log n)$ exceptionally efficient for querying massive, sorted datasets [7].

**Quadratic Time ($O(n^2)$)** represents severe performance degradation. This typically occurs when dealing with nested loops—a loop running inside another loop [7]. If an outer loop runs $n$ times and an inner loop runs $n$ times for every iteration of the outer loop, the total operations scale to $n \times n$, or $n^2$ [7]. As $n$ grows, quadratic algorithms quickly become unviable for large inputs [7].

### Code Comparison of $O(n)$ vs $O(n^2)$
```python
# O(n) Linear Time: Single loop over input
def print_items(arr):
    for item in arr:
        print(item)

# O(n^2) Quadratic Time: Nested loops over input
def print_pairs(arr):
    for i in arr:
        for j in arr:
            print(i, j)
```

When graphing these complexities, $O(1)$ is a flat line, $O(\log n)$ curves gently upward, $O(n)$ forms a straight diagonal line, and $O(n^2)$ shoots steeply upward, demonstrating why avoiding quadratic and exponential structures is vital for software engineering [3][7][13].

## End-to-End Analysis: Summing Numbers _(7 min)_

Let us examine two different implementations of a function that sums integers up to a given number $n$ [11]. Comparing them highlights how algorithmic design changes time complexity.

### Approach 1: Iterative Summation ($O(n)$)
```python
def add_up_iterative(n):
    total = 0
    for i in range(1, n + 1):
        total += i
    return total
```
In this iterative function, the `for` loop executes $n$ times [11]. If $n$ is 1,000,000, the loop runs one million times [11]. Therefore, the runtime grows linearly with $n$, making this an $O(n)$ linear time algorithm [11].

### Approach 2: Mathematical Formula ($O(1)$)
```python
def add_up_formula(n):
    return n * (n + 1) // 2
```
Using Carl Friedrich Gauss's famous summation formula, we perform a fixed sequence of arithmetic operations (one addition, one multiplication, and one integer division) regardless of the size of $n$ [5][11]. Even if $n$ is one billion, this function executes in just three steps [11]. 

### Why Constant Time Wins
Although Approach 2 technically performs a small constant number of primitive operations, Big-O notation drops these constant offsets [2][11][13]. We classify Approach 2 as $O(1)$ constant time [11]. Comparing $O(n)$ to $O(1)$ demonstrates why choosing a smarter mathematical or structural approach drastically improves scalability [11].

## Hands-On Activity: Code Complexity Inspector _(8 min)_

In this hands-on exercise, you will analyze three code snippets and classify their Big-O time complexity. 

### Steps to Complete:
1. Review the three code blocks below.
2. Trace how the execution steps change relative to the input variable $n$ or array length.
3. Determine whether the snippet represents $O(1)$, $O(n)$, or $O(n^2)$.

**Snippet A:**
```python
def check_first_and_last(arr):
    print(arr[0])
    print(arr[-1])
```
**Snippet B:**
```python
def find_item(arr, target):
    for item in arr:
        if item == target:
            return True
    return False
```
**Snippet C:**
```python
def duplicate_matrix(arr):
    matrix = []
    for x in arr:
        for y in arr:
            matrix.append((x, y))
    return matrix
```

### Expected Results:
* **Snippet A** is **$O(1)$** because it accesses fixed indices directly without loops [4][7].
* **Snippet B** is **$O(n)$** because its single loop scans across the array linearly in the worst-case scenario [7][8].
* **Snippet C** is **$O(n^2)$** because it features nested loops iterating over the collection twice, producing quadratic growth [7].

## Knowledge Check _(5 min)_

Complete the following 5 questions to test your understanding of Big-O notation and time complexity classes.

**Q1. What is the primary purpose of Big-O notation in computer science?**

- A. To measure the exact execution time of a program in milliseconds across all computers
- B. To describe the asymptotic growth of an algorithm's resource usage as input size increases
- C. To count the exact lines of source code written by a developer
- D. To determine the precise amount of electricity consumed by a CPU

**Q2. Why are constants and lower-order terms (such as the 4 and 2 in 4n^2 - 2n + 2) ignored in Big-O notation?**

- A. Because mathematical operations cannot handle negative numbers
- B. Because they depend on specific hardware and become insignificant when input size n gets extremely large
- C. Because constants always evaluate to zero in programming languages
- D. Because lowercase letters are used instead of numbers

**Q3. Which time complexity class represents the best performance where execution time remains completely flat regardless of input size?**

- A. O(n^2)
- B. O(n)
- C. O(log n)
- D. O(1)

**Q4. You are analyzing a function that contains two nested loops, where both loops iterate across an input array of size n. What is the time complexity?**

- A. O(1)
- B. O(log n)
- C. O(n)
- D. O(n^2)

**Q5. Scenario: Developer A writes a search algorithm that cuts the remaining searchable dataset in half during each step. Which time complexity category does this algorithm belong to?**

- A. O(1) Constant Time
- B. O(log n) Logarithmic Time
- C. O(n) Linear Time
- D. O(n^2) Quadratic Time

<details><summary>Answers</summary>

1. **B** - Big-O notation is an asymptotic notation used to describe how an algorithm's performance or runtime scales as the input size grows, independent of specific hardware [2][11][13].
2. **B** - Constants and lower-order terms are omitted because hardware speeds vary and, when input size n gets large enough, constants do not alter the overall asymptotic growth rate [2][11][13].
3. **D** - O(1) stands for constant time complexity, meaning the algorithm performs a fixed number of operations unaffected by input size [4][7].
4. **D** - Nested loops where an outer loop and inner loop both scale with input size n result in quadratic time complexity, O(n^2) [7].
5. **B** - When the input size is reduced by half during iteration or recursion (such as in binary search), the time complexity is logarithmic, O(log n) [7].

</details>

## Wrap-Up and Common Misconceptions _(2 min)_

Big-O notation provides a standardized language for evaluating how algorithm performance scales as input sizes grow [4][11][13]. Key takeaways include recognizing that $O(1)$ is constant, $O(n)$ scales linearly, $O(\log n)$ halves data partitions, and $O(n^2)$ introduces quadratic slowdowns from nested loops [7].

**Common Misconceptions:**
* *Misconception 1:* Big-O measures exact execution time in seconds. *Correction:* Big-O is machine-independent and measures growth rate relative to input size, ignoring hardware differences [11][13].
* *Misconception 2:* Constants like the `2` in $2n$ matter in Big-O analysis. *Correction:* Constants and lower-order terms are discarded because they do not impact asymptotic growth at scale [2][11][13].

## Supplementary videos (optional)

- [Learn Big O notation in 6 minutes 📈](https://www.youtube.com/watch?v=XMUe3zFhM5c) - Bro Code, 6 min. Bro Code's video provides clear, beginner-friendly explanations of why Big-O ignores constants and demonstrates concrete line-by-line step counts for O(1) versus O(n).
- [Big-O Notation - For Coding Interviews](https://www.youtube.com/watch?v=BgLTDT03QtU) - NeetCode, 21 min. NeetCode breaks down how execution time grows relative to input size and establishes clear visual intuitions for flat and linear runtime curves.

## References

1. [Time complexity - Wikipedia](https://en.wikipedia.org/wiki/Time_complexity) - _web_, en.wikipedia.org
2. [Big O notation (with a capital letter O, not a zero), also ...](https://web.mit.edu/16.070/www/lecture/big_o.pdf) - _web_, web.mit.edu
3. [Big O Notation and Time Complexity – Easily Explained](https://happycoders.eu/algorithms/big-o-notation-time-complexity) - _web_, happycoders.eu
4. [Mastering Big O Notation: Understanding Time and Space Complexity in Algorithms](https://medium.com/@DevChy/introduction-to-big-o-notation-time-and-space-complexity-f747ea5bca58) - _web_, medium.com
5. [Time Complexity (Big-O Notation) in Algorithms - DEV Community](https://dev.to/davinceleecode/time-complexity-big-o-notation-in-algorithms-22lf) - _web_, dev.to
6. [Big O Notation - GeeksforGeeks](https://www.geeksforgeeks.org/dsa/analysis-algorithms-big-o-analysis) - _web_, geeksforgeeks.org
7. [Big O Cheat Sheet – Time Complexity Chart](https://www.freecodecamp.org/news/big-o-cheat-sheet-time-complexity-chart) - _web_, freecodecamp.org
8. [Big-O Algorithm Complexity Cheat Sheet (Know Thy Complexities!) @ericdrowell](https://www.bigocheatsheet.com) - _web_, bigocheatsheet.com
11. [Learn Big O notation in 6 minutes 📈](https://www.youtube.com/watch?v=XMUe3zFhM5c) - _video_, youtube.com
12. [L-1.3: Asymptotic Notations | Big O | Big Omega | Theta Notations | Most Imp Topic Of Algorithm](https://www.youtube.com/watch?v=7dz8Iaf_weM) - _video_, youtube.com
13. [Big-O Notation - For Coding Interviews](https://www.youtube.com/watch?v=BgLTDT03QtU) - _video_, youtube.com
