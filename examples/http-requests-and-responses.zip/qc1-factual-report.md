# QC Layer 1 - Research & Factual Accuracy

**Verdict:** pass  |  **Score:** 94/100  |  **Run:** 2026-11-07T08:10:57.667Z

The lesson provides an accurate, well-structured, and technically sound introduction to HTTP request-response mechanics, focusing on GET vs. POST methods and 2xx, 4xx, and 5xx status code categories. HTTP request/response text examples, header descriptions, and status code semantics align with RFC 9110 specifications and cited source materials. A minor oversimplification occurs regarding HTTP version headers across protocol generations, but overall content quality, internal consistency, and alignment with learning objectives are high.

## Claim verification

| Section | Claim | Status | Evidence |
|---|---|---|---|
| sec-1 | Browsers act as clients sending HTTP requests to servers, which process actions on requested resources and return an HTTP response with a status code. | **supported** | Supported by S7 and S10, as well as RFC 9110 standard client-server HTTP communication model. S7 S10 S13 |
| sec-2 | GET requests are used to retrieve data from a server without altering the server's underlying state. | **supported** | RFC 9110 defines GET as a safe (read-only) method. Supported by S3, S7, and S8. S3 S7 S8 |
| sec-2 | POST requests carry data in the request body to perform an action or create a new entity on the server. | **supported** | Supported by S1, S3, and standard HTTP specifications for POST payload semantics. S1 S3 |
| sec-2 | In any compliant implementation, both the request and response must explicitly declare their HTTP version in their very first line. | **misleading** | While true for HTTP/1.0 and HTTP/1.1 start-lines (as cited in IBM S7 docs), HTTP/2 (RFC 7540) and HTTP/3 (RFC 9114) use binary frames with pseudo-header fields rather than textual request/status start-lines. S7 |
| sec-2 | Common request headers include User-Agent, Accept, Referer, and Cookie. | **supported** | Supported by S8 and standard HTTP request header definitions. S8 |
| sec-3 | An HTTP response contains a status line (HTTP version and 3-digit status code), response headers, and an optional response body. | **supported** | Supported by S7 and S13, as well as RFC 9110 Section 15. S7 S13 |
| sec-3 | 204 No Content indicates successful processing where no body content is returned, instructing the client view to remain unchanged. | **supported** | Supported by S2, S5 (W3C standard notes), and RFC 9110 Section 15.3.5. S2 S5 |
| sec-3 | 401 Unauthorized indicates the client is unauthenticated, whereas 403 Forbidden indicates identity is recognized but authorization is denied. | **supported** | Supported by S2 and HTTP authentication/authorization standards. S2 |
| sec-3 | 422 Unprocessable Entity means request syntax is correct but contains logical or semantic validation errors. | **supported** | Supported by S2, RFC 4918, and RFC 9110 Section 15.5.21. S2 |
| sec-3 | 502 Bad Gateway indicates an upstream server failed, while 504 Gateway Timeout indicates an upstream server timed out. | **supported** | Supported by S2 and standard HTTP server error code definitions. S2 |
| sec-4 | A successful GET request to /users/42 returns HTTP/1.1 200 OK with a JSON user object in the body. | **supported** | Format and status code align with S2, S3, S7, and REST conventions. S2 S3 S7 |
| sec-4 | Submitting a duplicate username in a POST request can trigger a 409 Conflict response. | **supported** | Supported by S2 and RFC 9110 Section 15.5.10 for state conflicts. S2 S5 |
| sec-5 | Submitting a payment form with missing fields should result in status code 400 Bad Request or 422 Unprocessable Entity. | **supported** | Supported by S2 and S5 for client data validation errors. S2 S5 |
| quiz | Status code 201 Created signifies that a request (typically POST) succeeded and resulted in creating a new entity. | **supported** | Supported by S2, S3, and RFC 9110 Section 15.3.2. S2 S3 |
| quiz | An unhandled backend database crash during request fulfillment requires a 500 Internal Server Error (5xx category) response. | **supported** | Supported by S2, S3, and S5 for server-side unhandled errors. S2 S3 S5 |

## Source assessment

| Source | Reliability | Relevance | Note |
|---|---|---|---|
| S1 | medium | high | Reddit developer discussion thread on HTTP status code practices. |
| S2 | medium | high | LinkedIn post detailing 2xx, 4xx, and 5xx breakdown summaries. |
| S3 | medium | high | Technical blog post covering status code decision trees for APIs. |
| S4 | medium | medium | CMS vendor knowledge base article providing basic summary of status code classes. |
| S5 | high | high | W3C official documentation on HTTP response status codes. |
| S6 | medium | high | REST API tutorial documentation covering status code categories. |
| S7 | high | high | IBM official documentation for z/OS CICS HTTP protocol specification. |
| S8 | medium | high | University web development lecture materials hosted on GitHub. |
| S9 | medium | low | YouTube video link included in source pack; not cited in lesson text. |
| S10 | medium | high | YouTube tutorial explaining client-server HTTP flow and status codes. |
| S11 | low | low | YouTube video listed in source pack; not cited in lesson text. |
| S12 | low | low | YouTube video listed in source pack; not cited in lesson text. |
| S13 | medium | high | YouTube educational video covering HTTP status code classifications and headers. |
| S14 | low | low | US GAO book on financial auditing. Off-topic artifact in source pack, not cited in lesson. |
| S15 | high | medium | Classic textbook on data communications; not cited directly in lesson text. |
| S16 | high | medium | Web application security textbook; not cited directly in lesson text. |

## Link checks

- OK (200) https://www.linkedin.com/posts/iammukeshm_http-status-codes-explained-2xx-here-activity-7428016944114561024-PcCS
- OK (200) https://shinesolutions.com/2016/06/03/the-most-important-thing-when-picking-http-status-codes
- OK (200) https://www.ibm.com/docs/en/cics-ts/5.6.0?topic=concepts-http-protocol
- OK (200) https://github.coventry.ac.uk/pages/CUEH/245CT/5_WebIntro/Requests
- OK (200) https://www.youtube.com/watch?v=9mMDcf_W2yU
- OK (200) https://www.youtube.com/watch?v=Km2VTefqfpk
- BLOCKED (timeout) https://openlibrary.org/works/OL35531W
- BLOCKED (timeout) https://openlibrary.org/works/OL13814659W

## Independent verification searches

- "HTTP 204 No Content status code response body RFC 9110 MDN" -> https://www.thestatuscode.com/2xx/204, https://restfulapi.net/http-status-204-no-content, https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Status/204
- "HTTP 422 Unprocessable Entity status code semantics syntax RFC 9110 RFC 4918 MDN" -> https://github.com/hyperium/http/issues/664, https://sslinsights.com/fix-http-422-unprocessable-entity-error, https://stackoverflow.com/questions/16133923/400-vs-422-response-to-post-of-data
- "HTTP request line start line protocol version requirement RFC 9110 RFC 7230" -> https://www.rfc-editor.org/info/rfc9110, https://httpwg.org/specs/rfc9110.html, https://www.rfc-editor.org/info/rfc7230
- "HTTP GET method safe idempotent server state modification RFC 9110 MDN" -> https://httpwg.org/specs/rfc9110.html, https://www.rfc-editor.org/info/rfc9110, https://developer.mozilla.org/en-US/docs/Glossary/Safe/HTTP

## Gaps

- The lesson omits formal HTTP terminology such as 'safe' and 'idempotent' methods when comparing GET and POST, which would provide valuable technical precision for API developers.

## Issues and suggested improvements

### 🟡 F1 - MINOR (misleading) in `sec-2`  _[open]_

**Problem:** The text states 'In any compliant implementation, both the request and response must explicitly declare their HTTP version (such as HTTP/1.0 or HTTP/1.1) in their very first line [S7].' This generalizes HTTP/1.x start-line requirements to all HTTP implementations, ignoring binary framing formats in HTTP/2 and HTTP/3.

**Evidence:** RFC 7540 (HTTP/2) and RFC 9114 (HTTP/3) do not use ASCII start-lines; control metadata and pseudo-headers are transmitted via binary frame structures.

**Suggestion:** Specify that declaring the HTTP version in the start-line is standard for HTTP/1.x request and response messages.

**Proposed change (replace):**

> Before: In any compliant implementation, both the request and response must explicitly declare their HTTP version (such as HTTP/1.0 or HTTP/1.1) in their very first line [S7].
> After: In HTTP/1.x implementations, both the request and response explicitly declare their HTTP version (such as HTTP/1.0 or HTTP/1.1) in their first line [S7].
