# References - HTTP Requests and Responses

2. [HTTP Status Codes Explained: 2xx, 4xx, 5xx Breakdown | Mukesh Murugan posted on the topic | LinkedIn](https://www.linkedin.com/posts/iammukeshm_http-status-codes-explained-2xx-here-activity-7428016944114561024-PcCS) - _web_, linkedin.com
3. [Shine Solutions - Considerations for Picking HTTP Status Codes](https://shinesolutions.com/2016/06/03/the-most-important-thing-when-picking-http-status-codes) - _web_, shinesolutions.com
7. [The HTTP protocol | CICS Transaction Server for z/OS 5.6.0 | IBM Documentation](https://www.ibm.com/docs/en/cics-ts/5.6.0?topic=concepts-http-protocol) - _web_, ibm.com
8. [Requests and Responses - 245CT](https://github.coventry.ac.uk/pages/CUEH/245CT/5_WebIntro/Requests) - _web_, github.coventry.ac.uk
10. [HTTP Status Codes Explained in One Video | 200, 404, 500, 401, 403, 301 | REST API Tutorial](https://www.youtube.com/watch?v=9mMDcf_W2yU) - _video_, youtube.com
13. [HTTP Status Codes Explained](https://www.youtube.com/watch?v=Km2VTefqfpk) - _video_, youtube.com
15. [Data Communications and Networking](https://openlibrary.org/works/OL35531W) - _book_, Further reading (metadata only)
16. [The web application hacker's handbook](https://openlibrary.org/works/OL13814659W) - _book_, Further reading (metadata only)

## Researched but not cited

- [4xx or 5xx for Missing Data? And How to Handle Duplicate Entries?](https://www.reddit.com/r/ExperiencedDevs/comments/1gbbb9a/4xx_or_5xx_for_missing_data_and_how_to_handle) (web)
- [HTTP Status Codes: Full List of All 63 Explained - Umbraco](https://umbraco.com/knowledge-base/http-status-codes) (web)
- [Status codes in HTTP](https://www.w3.org/Protocols/HTTP/HTRESP.html) (web)
- [HTTP Status Codes - REST API Tutorial](https://restfulapi.net/http-status-codes) (web)
- [HTTP Status Codes Explained In 5 Minutes](https://www.youtube.com/watch?v=qmpUfWN7hh4) (video)
- [HTTP Status Codes Explained with Real Life Examples | Hindi English](https://www.youtube.com/watch?v=R5UoMaPkZlc) (video)
- [HTTPS Explained: Structure, Request, Response, Methods & Status Codes in Tamil](https://www.youtube.com/watch?v=SfVPCGA7aN8) (video)
- [Financial audit](https://openlibrary.org/works/OL565229W) (book)

## Acknowledgement

Content was synthesised (paraphrased, not copied) with an AI model from the sources above. Sources are credited to their original authors.
