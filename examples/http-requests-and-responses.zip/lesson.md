# HTTP Requests and Responses

**Learning objective:** Explain GET and POST methods and distinguish between 2xx, 4xx, and 5xx response status categories.

**Duration:** 45 minutes

This 45-minute lesson introduces the core mechanics of HTTP request-response communication between web clients and servers. Learners will master GET and POST request methods, header structures, and HTTP status code categories including 2xx success, 4xx client errors, and 5xx server errors.

## By the end of this lesson you will be able to

- Differentiate between GET and POST HTTP request methods when communicating with a web server.
- Categorize HTTP response status codes into 2xx, 4xx, and 5xx categories based on operation outcomes.
- Identify common HTTP status codes such as 200, 201, 204, 400, 401, 403, 404, 500, and 503 in web applications.

## Why HTTP Requests and Responses Matter _(3 min)_

Every time you open a web browser, search for information, or submit an online form, your browser initiates a fundamental digital conversation [S8, S10]. Behind the scenes, the browser acts as a client sending structured HTTP requests to remote servers [S7, S10, S13]. The server processes these actions on requested resources and sends back an HTTP response paired with a specific status code [S1, S7, S13].

Imagine submitting an online order form only to encounter a cryptic error, or attempting to fetch a user profile page that no longer exists. Is the error due to invalid data you typed, or did the server crash internally? HTTP status codes explicitly answer this question, telling client applications whether an operation succeeded, whether the user made a mistake, or whether the server itself broke [S2, S3]. Mastering HTTP methods like GET and POST alongside status categories is essential for writing reliable applications and building clean APIs [S2, S8].

## HTTP Requests and Request Methods (GET vs POST) _(10 min)_

### Core Concept 1: HTTP Requests and Request Methods

Web communications rely on the Hypertext Transfer Protocol (HTTP), where a client (such as a web browser or an API tool like Postman) makes a request to a server hosting a resource [S7, S8, S10, S13]. The overall objective of an HTTP request is to access or perform an action on a specified resource located on the host server [S1, S7]. In any compliant implementation, both the request and response must explicitly declare their HTTP version (such as HTTP/1.0 or HTTP/1.1) in their very first line [7].

#### HTTP Request Methods: GET vs POST

HTTP defines specific request methods to indicate the desired action on a resource [S1, S8]. Two of the most foundational methods are GET and POST:

1. **GET Requests**: A GET request is used when a client wants to retrieve data or fetch a representation of an existing resource from the server [S3, S7, S8]. For instance, when you type a web address into a browser or search online, the browser sends a GET request [S8, S10]. GET requests are intended to pull information without altering the server's underlying state. When a GET request succeeds, the server returns the requested resource representation, such as an HTML document, JSON object, or XML payload [3].

2. **POST Requests**: A POST request is used when the client submits data to the server to perform an action or create a new entity [S1, S3]. For example, submitting a sign-up form, sending dynamic payload data via dynamic web scripts, or posting new records uses POST [S3, S8]. Unlike GET, a POST request carries data in its request body. Upon processing a successful POST request, the server creates the entity and typically returns a response containing the new entity's unique ID or an echoed representation of the created resource [3].

#### HTTP Request Structure and Headers

Every HTTP request consists of a request line, header fields, and an optional message body [S7, S8]. The request line contains the HTTP method, the target URL resource, and the HTTP version [S7, S8]. Following the request line are headers that convey metadata [8]. Common request headers include:
- `User-Agent`: Supplies information about the client software or browser sending the request (often containing historical browser identifiers) [8].
- `Accept`: Specifies the data formats (such as `application/json` or `text/html`) that the client expects to receive in response [8].
- `Referer`: Indicates the URL of the previous web page from which the current request originated [8].
- `Cookie`: Transmits stored cookie key-value pairs back to the server [8].

#### Example HTTP Request

Below is an example of a simple HTTP GET request asking for a user profile in JSON format:

```http
GET /api/v1/users/42 HTTP/1.1
Host: api.example.com
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)
Accept: application/json
Referer: https://example.com/dashboard
```

In this request, the client uses `GET` to target `/api/v1/users/42` under protocol `HTTP/1.1` [S7, S8]. Headers tell the server which host to contact, what response format is expected, and where the user came from [8].

## HTTP Responses and Status Code Categories (2xx, 4xx, 5xx) _(10 min)_

### Core Concept 2: HTTP Responses and Status Code Categories

When an HTTP server receives and evaluates a request, it replies with an HTTP response [S7, S10, S13]. An HTTP response contains three major components: a status line (including the HTTP version and a 3-digit status code), response headers, and an optional response body [S7, S13]. The 3-digit HTTP status code communicates the outcome of the requested action to the client [S1, S13]. Because HTTP status codes are universally recognized standards, clients across all programming technologies—whether Java, .NET, MuleSoft, or browser scripts—interpret these numbers identically [13].

Status codes are grouped into distinct numerical ranges based on their standard meaning [S2, S6, S13]:

#### 1. 2xx Category: Success ("Here you go")
Codes in the 2xx range indicate that the server successfully received, understood, and executed the action requested by the client [S2, S3, S6]. Key 2xx codes include:
- **200 OK**: The standard response for a successful request where the server delivers the requested data [2].
- **201 Created**: Returned when a request (typically POST) successfully creates a new entity on the server [S2, S3].
- **202 Accepted**: The server has received and accepted the request for processing, but processing is not yet completed [2].
- **204 No Content**: The server successfully processed the request, but there is no body content to return, instructing the client view to remain unchanged [S2, S5].

#### 2. 4xx Category: Client Error ("You messed up")
The 4xx range communicates that an error occurred due to a client-side issue [S2, S3, S5]. Common 4xx status codes include:
- **400 Bad Request**: The server cannot understand or process the request due to malformed syntax or bad parameters [S2, S5].
- **401 Unauthorized**: The client is unauthenticated and must log in before accessing the resource [2].
- **403 Forbidden**: The server recognizes the client's identity, but authorization is denied [2].
- **404 Not Found**: The requested resource does not exist on the server [2].
- **409 Conflict**: The request conflicts with the current state of the target resource [2].
- **422 Unprocessable Entity**: The request syntax is correct, but contains logical or semantic validation errors [2].

#### 3. 5xx Category: Server Error ("I messed up")
The 5xx range indicates that the server encountered an internal failure while trying to fulfill a valid request [S2, S3, S5]. Standard 5xx status codes include:
- **500 Internal Server Error**: The server encountered an unexpected failure on its end [2].
- **502 Bad Gateway**: An upstream server or gateway behind the primary server failed [2].
- **503 Service Unavailable**: The server is temporarily overloaded or down for maintenance [2].
- **504 Gateway Timeout**: An upstream gateway failed to respond within the expected time limit [2].

#### Example HTTP Response

Here is a response returning a 201 Created code after creating a new resource:

```http
HTTP/1.1 201 Created
Content-Type: application/json
Location: /api/v1/users/105

{
  "id": 105,
  "name": "Jane Doe",
  "status": "active"
}
```

APIs must return accurate status codes; returning a `200 OK` code when an internal error occurs misleads client applications [2].

## Worked End-to-End Example: GET and POST Workflows _(7 min)_

### Worked End-to-End Example: GET and POST Workflows

Let's trace two real-world HTTP exchanges between a web client and an API server to illustrate how requests and responses function end-to-end [S7, S8, S13].

#### Scenario 1: Fetching User Data with GET

A client web application sends an HTTP GET request to retrieve account details for user ID 42 [S7, S8].

**Client Request:**
```http
GET /users/42 HTTP/1.1
Host: api.store.com
User-Agent: Mozilla/5.0
Accept: application/json
```

**Server Processing & Response:**
The server validates the request URL, verifies that user 42 exists in the database, and builds a JSON representation of the user entity [S3, S7, S10]. Because the action succeeded, it replies with a `200 OK` status code [S2, S3]:

```http
HTTP/1.1 200 OK
Content-Type: application/json

{
  "id": 42,
  "username": "alex_dev",
  "email": "alex@example.com"
}
```

#### Scenario 2: Registering a New User with POST

Next, a user submits a registration form. The client application packages the submitted form data into the body of an HTTP POST request [S3, S8].

**Client Request:**
```http
POST /users HTTP/1.1
Host: api.store.com
Content-Type: application/json
Accept: application/json

{
  "username": "sam_coder",
  "email": "sam@example.com"
}
```

**Server Error Response (Validation Failure):**
Suppose `sam_coder` already exists in the system. The server cannot fulfill the request due to a data conflict [2]. Instead of returning success, the server responds with a 4xx client error status code `409 Conflict` and a human-readable error payload [S2, S5]:

```http
HTTP/1.1 409 Conflict
Content-Type: application/json

{
  "error": "UserExists",
  "message": "The username sam_coder is already taken."
}
```

This request-response pattern ensures that the server clearly communicates the result of every client action using standardized HTTP conventions [S2, S7, S13].

## Hands-On Activity: HTTP Request & Status Code Categorization _(8 min)_

### Hands-On Activity: HTTP Request & Status Code Categorization

In this activity, you will analyze four HTTP communication scenarios and determine the appropriate HTTP request method and 3-digit status code for each [S2, S3, S8].

#### Activity Steps:
1. Review the scenario description and client intent.
2. Identify whether the client should use a **GET** or **POST** request method [S3, S8].
3. Select the exact 3-digit HTTP status code and category (2xx, 4xx, or 5xx) the server should return [S2, S3, S5].

#### Scenarios to Evaluate:
- **Scenario A**: A browser requests the main product catalog page (`/products`). The catalog page is found and rendered successfully [S2, S3].
- **Scenario B**: A user submits a payment form with missing credit card fields to create an order [S2, S5].
- **Scenario C**: A client sends a request to `/dashboard`, but the client has not logged in or provided credentials [2].
- **Scenario D**: A client sends a valid search query, but the backend database server crashes unexpectedly during processing [S2, S5].

#### Expected Results:
- **Scenario A**: Method: **GET**; Status Code: **200 OK** (2xx Success) [S2, S3].
- **Scenario B**: Method: **POST**; Status Code: **400 Bad Request** or **422 Unprocessable Entity** (4xx Client Error) [S2, S5].
- **Scenario C**: Method: **GET**; Status Code: **401 Unauthorized** (4xx Client Error) [2].
- **Scenario D**: Method: **GET**; Status Code: **500 Internal Server Error** (5xx Server Error) [S2, S5].

## Knowledge Check _(5 min)_

Test your understanding of HTTP request methods and status code categories (2xx, 4xx, 5xx) with the following 5 questions. Select the single best answer for each question.

**Q1. Which HTTP request method should a web client use when retrieving data from a server without modifying any server resources?**

- A. POST
- B. GET
- C. 200 OK
- D. Accept

**Q2. Which status code category indicates that an HTTP request failed because of a client-side issue, such as malformed syntax or missing credentials?**

- A. 2xx category
- B. 3xx category
- C. 4xx category
- D. 5xx category

**Q3. A web application sends a POST request to register a new account. The server successfully creates the new account entity and returns its unique ID. Which HTTP status code should the server reply with?**

- A. 201 Created
- B. 204 No Content
- C. 400 Bad Request
- D. 500 Internal Server Error

**Q4. While navigating a website, a browser attempts to access a page URL that does not exist on the server. Which specific status code and category will the server return?**

- A. 500 Internal Server Error (5xx category)
- B. 404 Not Found (4xx category)
- C. 204 No Content (2xx category)
- D. 401 Unauthorized (4xx category)

**Q5. A client sends a valid GET request to an API endpoint, but an unhandled exception causes the server's backend database to crash during processing. Which status code category and code must the server return?**

- A. 200 OK (2xx category)
- B. 400 Bad Request (4xx category)
- C. 422 Unprocessable Entity (4xx category)
- D. 500 Internal Server Error (5xx category)

<details><summary>Answers</summary>

1. **B** - GET requests are used by clients to retrieve or fetch data representations from a server without modifying server resources [S3, S7, S8].
2. **C** - The 4xx range communicates that an error occurred due to a client fault, such as submitting bad data, failing to authenticate, or requesting a missing page [S2, S3, S5].
3. **A** - Status code 201 Created signifies that a request (typically POST) succeeded and resulted in the creation of a new entity on the server [S2, S3].
4. **B** - 404 Not Found is a 4xx client error status code returned when the server cannot locate the requested resource [2].
5. **D** - When an unexpected server-side error or crash prevents fulfilling a valid request, the server must return a 5xx series code, specifically 500 Internal Server Error [S2, S3, S5].

</details>

## Lesson Wrap-Up and Key Takeaways _(2 min)_

### Lesson Wrap-Up and Key Takeaways

In this lesson, we explored how HTTP request-response architecture forms the backbone of web interaction [S7, S8, S13]. Clients use GET to retrieve data without state changes and POST to submit data for entity creation or processing [S3, S8]. Server responses use standard 3-digit status codes divided into major categories: 2xx for success ("Here you go"), 4xx for client-side errors ("You messed up"), and 5xx for server-side failures ("I messed up") [S2, S3, S5].

A common misconception is that returning `200 OK` with an error message inside the body is acceptable; in reality, doing so lies to client HTTP libraries and breaks standard error handling protocols [S2, S3]. Always select the status code that communicates true intent [2].

## Supplementary videos (optional)

- [HTTP Status Codes Explained in One Video | 200, 404, 500, 401, 403, 301 | REST API Tutorial](https://www.youtube.com/watch?v=9mMDcf_W2yU) - CodeAxis, 19 min. Provides a clear explanation of client-server HTTP request flows, browser network tab inspection, and server response validation.
- [HTTP Status Codes Explained](https://www.youtube.com/watch?v=Km2VTefqfpk) - Integration World, 9 min. Explains the 3-digit HTTP response status code structure, message headers, and category breakdowns across API technologies.

## References

2. [HTTP Status Codes Explained: 2xx, 4xx, 5xx Breakdown | Mukesh Murugan posted on the topic | LinkedIn](https://www.linkedin.com/posts/iammukeshm_http-status-codes-explained-2xx-here-activity-7428016944114561024-PcCS) - _web_, linkedin.com
3. [Shine Solutions - Considerations for Picking HTTP Status Codes](https://shinesolutions.com/2016/06/03/the-most-important-thing-when-picking-http-status-codes) - _web_, shinesolutions.com
7. [The HTTP protocol | CICS Transaction Server for z/OS 5.6.0 | IBM Documentation](https://www.ibm.com/docs/en/cics-ts/5.6.0?topic=concepts-http-protocol) - _web_, ibm.com
8. [Requests and Responses - 245CT](https://github.coventry.ac.uk/pages/CUEH/245CT/5_WebIntro/Requests) - _web_, github.coventry.ac.uk
10. [HTTP Status Codes Explained in One Video | 200, 404, 500, 401, 403, 301 | REST API Tutorial](https://www.youtube.com/watch?v=9mMDcf_W2yU) - _video_, youtube.com
13. [HTTP Status Codes Explained](https://www.youtube.com/watch?v=Km2VTefqfpk) - _video_, youtube.com
15. [Data Communications and Networking](https://openlibrary.org/works/OL35531W) - _book_, Further reading (metadata only)
16. [The web application hacker's handbook](https://openlibrary.org/works/OL13814659W) - _book_, Further reading (metadata only)
